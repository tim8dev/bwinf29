package de.voodle.tim.bwinf.kisten
package bench

import core._

import java.util.concurrent.Future
import scala.actors.Actor
import Actor._

private[bench] abstract sealed trait BenchNachricht
private[bench] case object StarteBench extends BenchNachricht
private[bench] case object StoppeBench extends BenchNachricht
private[bench] abstract sealed trait GibNachricht extends BenchNachricht
private[bench] case object GibAussenVolumen extends GibNachricht
private[bench] case object Gib extends GibNachricht
//private[bench] case class SetzeWert extends BenchNachricht

class Bencher(packer: BenchPacker) {
  //def this(packer: HilfsPacken) = this(BenchPacker(packer))
  private val benchActor = new Actor {
    val benchPacker = packer
     def act {
       loop {
         react {
           case StarteBench =>
             benchPacker.start()
           case StoppeBench =>
             benchPacker.exit()
           case GibAussenVolumen =>
             reply(benchPacker.aussenVolumen)
         }
       }
     }
  }

  def start = benchActor.start();
  def stop(force: Boolean) =
    if(force) benchActor !? StoppeBench
    else () // TODO: Wait for termination.

  def aussenVolumen: Long = 0
  def summeEinzelvolumen: Long = 0
  def anzahlKistenSaetze: Long = 0
  //def aktuellerWert: Long = (benchActor !! GibAussenVolumen)().asInstanceOf[Long]
}
/*
object BenchPacker {
  def apply(packer: HilfsPacken) =
    new SimplerPacker(packer.kisten) with BenchPacker {
      override def min = packer.min
      def packe = packer.packe
    }
}*/

trait BenchPacker extends KistenPacker with Actor {
  // Aktuelle Werte:
  @volatile def aussenVolumen: Long
  @volatile def summeEinzelvolumen: Long
  @volatile def anzahlKistenSaetze: Long
  
  def act {
    this.min
  }
  
  override def exit = this.exit
}
/*
case class BenchPacker(packer: HilfsPacken) extends HilfsPacken with Actor {
  def aktuellerWert = aktWert
  @volatile private var aktWert: Long = 0
  def kisten = packer.kisten
  override protected def hilfsPacken(sätze: Set[KistenSatz], kiste: Kiste) = {
    val ergebnis = packer.hilfsPacken(sätze, kiste)
    aktWert = sätze.size
    ergebnis
  }

  def act {
    this.packe
  }

  def exit {
    this.exit
  }
}*/
