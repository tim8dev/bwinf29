package de.voodle.tim.bwinf.kartons.core
package online

import org.specs._
import org.scalacheck._
/*
object OnlinePackerSpec extends Specification with ScalaCheck {
  import Prop.forAll
  "A Online KartonPacker " should {
    
  }
}*/
